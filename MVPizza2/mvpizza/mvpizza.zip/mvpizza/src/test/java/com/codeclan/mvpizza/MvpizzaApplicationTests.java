package com.codeclan.mvpizza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvpizzaApplicationTests {

	@Test
	void contextLoads() {
	}

}
