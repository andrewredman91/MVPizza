package com.codeclan.mvpizza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvpizzaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvpizzaApplication.class, args);
	}

}
